
A bank is implementing a system to identify potential customers who have higher probablity of availing loans to increase its profit.

Attributes:

ID - A unique identifier 
Age 
Number of years of experience
Annual Income 
ZIPCode
Family size
Avgerage spending per month 
Education Level. 1: 12th; 2: Graduate; 3: Post Graduate 
Mortgage Value of house if any 
Did this customer accept the personal loan offered in the last campaign? -- Output label
Does the customer have a securities account with the bank? 
Does the customer have a certificate of deposit (CD) account with the bank? 
Does the customer use internet banking facilities? 
Does the customer uses a credit card issued by UniversalBank?
