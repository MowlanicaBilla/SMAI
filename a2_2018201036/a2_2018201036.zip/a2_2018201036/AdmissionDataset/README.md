The dataset contains several parameters which are considered important during the application for Masters Programs. 

Number of instances: 500

Number of Input attributes: 7

	1. ID
	2. GRE Scores ( out of 340 ) 
	3. TOEFL Scores ( out of 120 ) 
	4. University Rating ( out of 5 ) 
	5. Statement of Purpose and Letter of Recommendation Strength ( out of 5 ) 
	6. Undergraduate GPA ( out of 10 ) 
	7. Research Experience ( either 0 or 1 ) 

Output label: Chance of Admit ( ranging from 0 to 1 )